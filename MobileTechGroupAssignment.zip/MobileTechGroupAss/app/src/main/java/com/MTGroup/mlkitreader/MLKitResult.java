package com.MTGroup.mlkitreader;

public class MLKitResult {
    private String reader;
    private String text;
    private String filename;

    public MLKitResult(String reader, String text, String filename) {
        this.reader = reader;
        this.text = text;
        this.filename = filename;
    }

    public String getReader()   { return reader; }
    public String getText()     { return text; }
    public String getFilename() { return filename; }
}
