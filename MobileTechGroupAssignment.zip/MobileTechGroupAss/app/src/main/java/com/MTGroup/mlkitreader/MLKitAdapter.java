package com.MTGroup.mlkitreader;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.InputStream;
import java.util.List;

public class MLKitAdapter extends ArrayAdapter<MLKitResult> {

    private Context context;
    private List<MLKitResult> items;

    public MLKitAdapter(Context context, List<MLKitResult> items) {
        super(context, 0, items);
        this.context = context;
        this.items = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                .inflate(R.layout.list_item, parent, false);
        }

        MLKitResult item = items.get(position);
        ImageView imageView = convertView.findViewById(R.id.itemImage);
        TextView textView = convertView.findViewById(R.id.itemText);

        textView.setText(item.getReader());

        if (position % 2 == 0) {
            convertView.setBackgroundColor(0xFFFFFFFF);
        } else {
            convertView.setBackgroundColor(0xFFDDDDDD);
        }

        loadImageFromGallery(item.getFilename(), imageView);

        return convertView;
    }

    private void loadImageFromGallery(String filename, ImageView imageView) {
        try {
            android.content.ContentResolver resolver = context.getContentResolver();
            android.database.Cursor cursor = resolver.query(
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{
                    android.provider.MediaStore.Images.Media._ID,
                    android.provider.MediaStore.Images.Media.DISPLAY_NAME
                },
                android.provider.MediaStore.Images.Media.DISPLAY_NAME + "=?",
                new String[]{filename + ".jpg"},
                null
            );
            if (cursor != null && cursor.moveToFirst()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(
                    android.provider.MediaStore.Images.Media._ID));
                Uri imageUri = Uri.withAppendedPath(
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    String.valueOf(id));
                InputStream is = resolver.openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(is);
                imageView.setImageBitmap(bitmap);
                if (is != null) is.close();
                cursor.close();
            } else {
                imageView.setImageResource(android.R.drawable.ic_menu_gallery);
            }
        } catch (Exception e) {
            e.printStackTrace();
            imageView.setImageResource(android.R.drawable.ic_menu_gallery);
        }
    }
}
