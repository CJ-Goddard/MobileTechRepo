package com.MTGroup.mlkitreader;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.io.IOException;

public class Activity2 extends AppCompatActivity {

    private String readerType;
    private String currentResults;
    private Uri currentImageUri;
    private Uri photoUri;

    private TextView tvTitle;
    private TextView tvSubtitle;
    private ImageView imageMain;
    private Button btnEditResult;
    private Button btnOpenCamera;
    private Button btnLoadImage;

    // Handles taking a photo using the system camera
    private final ActivityResultLauncher<Uri> takePictureLauncher =
            registerForActivityResult(new ActivityResultContracts.TakePicture(),
                    success -> {
                        if (success && photoUri != null) {
                            currentImageUri = photoUri;
                            imageMain.setImageURI(currentImageUri);
                            analyseImage(currentImageUri);
                        }
                    });

    // Handles picking an image from the gallery
    private final ActivityResultLauncher<String> pickImageLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(),
                    uri -> {
                        if (uri != null) {
                            try {
                                getContentResolver().takePersistableUriPermission(
                                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            } catch (SecurityException e) {
                                // Fallback if URI isn't persistable
                                e.printStackTrace();
                            }
                            currentImageUri = uri;
                            imageMain.setImageURI(currentImageUri);
                            analyseImage(currentImageUri);
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);

        tvTitle = findViewById(R.id.tvTitle);
        tvSubtitle = findViewById(R.id.tvSubtitle);
        imageMain = findViewById(R.id.imageMain);
        btnOpenCamera = findViewById(R.id.btnOpenCamera);
        btnLoadImage = findViewById(R.id.btnLoadImage);
        btnEditResult = findViewById(R.id.btnEditResult);

        readerType = getIntent().getStringExtra("READER_TYPE");

        // Set initial image based on reader type from Activity1
        if ("barcode".equals(readerType)) {
            imageMain.setImageResource(R.drawable.barcode);
        } else if ("content".equals(readerType)) {
            imageMain.setImageResource(R.drawable.content);
        } else if ("text".equals(readerType)) {
            imageMain.setImageResource(R.drawable.text);
        }

        // Open camera after permission check
        btnOpenCamera.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CAMERA}, 100);
            } else {
                launchCamera();
            }
        });

        // Open gallery - GetContent doesn't require storage permissions on modern Android
        btnLoadImage.setOnClickListener(v -> pickImageLauncher.launch("image/*"));

        // Navigate to Activity5 for editing
        btnEditResult.setOnClickListener(v -> {
            if (currentImageUri == null) {
                Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(Activity2.this, Activity5.class);
            intent.putExtra("READER_TYPE", readerType);
            intent.putExtra("READER_LABEL", tvTitle.getText().toString());
            intent.putExtra("ML_RESULTS", currentResults);
            intent.putExtra("IMAGE_URI", currentImageUri.toString());
            intent.putExtra("IS_NEW_IMAGE", true);
            startActivity(intent);
        });
    }

    private void launchCamera() {
        try {
            File photoFile = new File(getExternalFilesDir(null), "temp_photo.jpg");
            photoUri = FileProvider.getUriForFile(this,
                    getPackageName() + ".fileprovider", photoFile);
            takePictureLauncher.launch(photoUri);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to launch camera", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                launchCamera();
            } else {
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (currentImageUri != null) {
            outState.putString("currentImageUri", currentImageUri.toString());
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if (savedInstanceState.containsKey("currentImageUri")) {
            currentImageUri = Uri.parse(savedInstanceState.getString("currentImageUri"));
        }
    }

    private void analyseImage(Uri imageUri) {
        try {
            InputImage image = InputImage.fromFilePath(this, imageUri);

            if ("barcode".equals(readerType)) {
                BarcodeScanner scanner = BarcodeScanning.getClient();
                scanner.process(image)
                        .addOnSuccessListener(barcodes -> {
                            StringBuilder sb = new StringBuilder("Detected barcode:\n");
                            for (Barcode barcode : barcodes) {
                                sb.append(barcode.getRawValue()).append("\n");
                            }
                            showResults(sb.toString());
                        })
                        .addOnFailureListener(e -> showResults("Barcode detection failed: " + e.getMessage()));

            } else if ("content".equals(readerType)) {
                ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
                labeler.process(image)
                        .addOnSuccessListener(labels -> {
                            StringBuilder sb = new StringBuilder("Recognised image content:\n");
                            int count = 1;
                            for (ImageLabel label : labels) {
                                sb.append(count++).append(". ")
                                        .append(label.getText())
                                        .append(" (")
                                        .append(String.format("%.2f", label.getConfidence() * 100))
                                        .append("% confidence)\n");
                            }
                            showResults(sb.toString());
                        })
                        .addOnFailureListener(e -> showResults("Image labeling failed: " + e.getMessage()));

            } else if ("text".equals(readerType)) {
                TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                recognizer.process(image)
                        .addOnSuccessListener(visionText -> {
                            String result = visionText.getText();
                            if (result.isEmpty()) result = "No text detected";
                            showResults("Extracted text:\n" + result);
                        })
                        .addOnFailureListener(e -> showResults("Text recognition failed: " + e.getMessage()));
            }

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
        }
    }

    private void showResults(String mlKitResult) {
        currentResults = mlKitResult;

        if ("barcode".equals(readerType)) {
            tvTitle.setText("Barcode Reader");
        } else if ("content".equals(readerType)) {
            tvTitle.setText("Content Reader");
        } else if ("text".equals(readerType)) {
            tvTitle.setText("Text Reader");
        }

        tvSubtitle.setText(mlKitResult);
        btnEditResult.setVisibility(View.VISIBLE);
    }
}