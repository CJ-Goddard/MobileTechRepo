package com.MTGroup.mlkitreader;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Activity7 extends AppCompatActivity {

    private TextView tvReader, tvResults;
    private ImageView imageItem;
    private Button btnEdit, btnDelete, btnCancel;
    private DatabaseReference databaseRef;
    private String firebaseKey;
    private String imageFilename;
    private String currentReader;
    private String currentResults;
    private Uri currentImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seven);

        tvReader = findViewById(R.id.tvReader);
        tvResults = findViewById(R.id.tvResults);
        imageItem = findViewById(R.id.imageItem);
        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);
        btnCancel = findViewById(R.id.btnCancel);

        // Read Intent extras
        firebaseKey = getIntent().getStringExtra("FIREBASE_KEY");
        imageFilename = getIntent().getStringExtra("IMAGE_FILENAME");

        // Disable buttons until data is loaded
        btnEdit.setEnabled(false);
        btnDelete.setEnabled(false);

        // Initialize Firebase reference
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        databaseRef = database.getReference("Storage").child(firebaseKey);

        // Download fresh data
        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                currentReader = snapshot.child("reader").getValue(String.class);
                currentResults = snapshot.child("text").getValue(String.class);
                String filename = snapshot.child("filename").getValue(String.class);

                if (currentReader != null) tvReader.setText(currentReader);
                if (currentResults != null) tvResults.setText(currentResults);

                if (filename != null) {
                    loadImageFromGallery(filename);
                }

                // Enable buttons
                btnEdit.setEnabled(true);
                btnDelete.setEnabled(true);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Activity7.this, "Failed to load data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                openActivity6();
            }
        });

        // Set up button listeners
        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity5.class);
            intent.putExtra("IS_NEW_IMAGE", false);
            intent.putExtra("FIREBASE_KEY", firebaseKey);
            intent.putExtra("IMAGE_FILENAME", imageFilename);
            intent.putExtra("READER_LABEL", currentReader);
            intent.putExtra("ML_RESULTS", currentResults);
            intent.putExtra("IMAGE_URI", currentImageUri != null ? currentImageUri.toString() : "");
            startActivity(intent);
        });

        btnDelete.setOnClickListener(v -> {
            DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("Storage");
            rootRef.child(firebaseKey).removeValue()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                        openActivity6();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Delete failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        });

        btnCancel.setOnClickListener(v -> openActivity6());
    }

    private void loadImageFromGallery(String filename) {
        try {
            android.content.ContentResolver resolver = getContentResolver();
            android.database.Cursor cursor = resolver.query(
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    new String[]{
                            android.provider.MediaStore.Images.Media._ID,
                            android.provider.MediaStore.Images.Media.DISPLAY_NAME
                    },
                    android.provider.MediaStore.Images.Media.DISPLAY_NAME + "=?",
                    new String[]{filename + ".jpg"},
                    null
            );
            if (cursor != null && cursor.moveToFirst()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(
                        android.provider.MediaStore.Images.Media._ID));
                currentImageUri = Uri.withAppendedPath(
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        String.valueOf(id));
                imageItem.setImageURI(currentImageUri);
                cursor.close();
            } else {
                imageItem.setImageResource(android.R.drawable.ic_menu_gallery);
                if (cursor != null) cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            imageItem.setImageResource(android.R.drawable.ic_menu_gallery);
        }
    }

    private void openActivity6() {
        Intent intent = new Intent(this, Activity6.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }


}
