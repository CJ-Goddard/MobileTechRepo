package com.MTGroup.mlkitreader;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;

public class Activity5 extends AppCompatActivity {

    private EditText etReaderLabel, etMlResults;
    private ImageView imageSaved;
    private Button btnSave;
    private boolean isNewImage;
    private String firebaseKey;
    private String imageFilename;
    private Uri imageUri;
    private DatabaseReference databaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_five);

        etReaderLabel = findViewById(R.id.etReaderLabel);
        etMlResults = findViewById(R.id.etMlResults);
        imageSaved = findViewById(R.id.imageSaved);
        btnSave = findViewById(R.id.btnSave);

        // 1. Initialize Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        databaseRef = database.getReference("Storage");

        // 2. Read all Intent extras
        isNewImage = getIntent().getBooleanExtra("IS_NEW_IMAGE", true);
        String label = getIntent().getStringExtra("READER_LABEL");
        String results = getIntent().getStringExtra("ML_RESULTS");
        String uriStr = getIntent().getStringExtra("IMAGE_URI");
        firebaseKey = getIntent().getStringExtra("FIREBASE_KEY");
        imageFilename = getIntent().getStringExtra("IMAGE_FILENAME");
        
        if (uriStr != null) {
            imageUri = Uri.parse(uriStr);
            
            // Image loading fallback
            if (uriStr.startsWith("file://") || uriStr.startsWith("/")) {
                String path = imageUri.getPath();
                if (path != null) {
                    File imgFile = new File(path);
                    if (imgFile.exists()) {
                        imageSaved.setImageBitmap(BitmapFactory.decodeFile(imgFile.getAbsolutePath()));
                    }
                }
            } else {
                imageSaved.setImageURI(imageUri);
            }
        }

        // 3. Pre-fill the EditTexts
        etReaderLabel.setText(label);
        etMlResults.setText(results);

        // 5. Set up btnSave click listener
        btnSave.setOnClickListener(v -> saveRecord());
    }

    private void saveRecord() {
        String updatedLabel = etReaderLabel.getText().toString().trim();
        String updatedResults = etMlResults.getText().toString().trim();

        if (isNewImage) {
            // Step 1: Generate a unique key from timestamp
            String timestamp = String.valueOf(System.currentTimeMillis());

            // Step 2: Save image to gallery (MediaStore)
            String savedUri = saveImageToStorage(imageUri, timestamp);
            if (savedUri == null) {
                Toast.makeText(this, "Failed to save image to gallery", Toast.LENGTH_SHORT).show();
                return;
            }

            // Step 3: Save text data to Firebase as a NEW node
            HashMap<String, String> itemMap = new HashMap<>();
            itemMap.put("filename", timestamp);
            itemMap.put("reader", updatedLabel);
            itemMap.put("text", updatedResults);

            databaseRef.child(timestamp).setValue(itemMap)
                    .addOnSuccessListener(aVoid -> openActivity6())
                    .addOnFailureListener(e -> Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        } else {
            // Update EXISTING Firebase node
            HashMap<String, Object> updates = new HashMap<>();
            updates.put("reader", updatedLabel);
            updates.put("text", updatedResults);

            databaseRef.child(firebaseKey).updateChildren(updates)
                    .addOnSuccessListener(aVoid -> openActivity6())
                    .addOnFailureListener(e -> Toast.makeText(this, "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }
    }

    private String saveImageToStorage(Uri sourceUri, String filename) {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, filename + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES);
            }
            Uri imageUri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (imageUri == null) return null;

            OutputStream os = getContentResolver().openOutputStream(imageUri);
            InputStream is = getContentResolver().openInputStream(sourceUri);
            if (os == null || is == null) return null;

            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
            os.close();
            is.close();
            return imageUri.toString();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void openActivity6() {
        Intent intent = new Intent(this, Activity6.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}
