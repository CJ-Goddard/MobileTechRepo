package com.MTGroup.mlkitreader;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class Activity6 extends AppCompatActivity {

    private ListView listView;
    private List<MLKitResult> mlKitResults;
    private MLKitAdapter adapter;
    private DatabaseReference databaseRef;
    private ChildEventListener childEventListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_six);

        listView = findViewById(R.id.listView);
        Button btnAdd = findViewById(R.id.btnAdd);

        // 1. Initialize Firebase reference
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        databaseRef = database.getReference("Storage");

        // 2. Initialize list and adapter
        mlKitResults = new ArrayList<>();
        adapter = new MLKitAdapter(this, mlKitResults);
        listView.setAdapter(adapter);

        // 3. Load data from Firebase using addChildEventListener
        childEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                String reader = snapshot.child("reader").getValue(String.class);
                String text = snapshot.child("text").getValue(String.class);
                String filename = snapshot.child("filename").getValue(String.class);
                if (reader != null && filename != null) {
                    mlKitResults.add(new MLKitResult(reader, text, filename));
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                String reader = snapshot.child("reader").getValue(String.class);
                String text = snapshot.child("text").getValue(String.class);
                String filename = snapshot.child("filename").getValue(String.class);
                if (filename != null) {
                    for (int i = 0; i < mlKitResults.size(); i++) {
                        if (mlKitResults.get(i).getFilename().equals(filename)) {
                            mlKitResults.set(i, new MLKitResult(reader, text, filename));
                            adapter.notifyDataSetChanged();
                            break;
                        }
                    }
                }
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                String filename = snapshot.child("filename").getValue(String.class);
                if (filename != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        mlKitResults.removeIf(item -> item.getFilename().equals(filename));
                    } else {
                        for (int i = 0; i < mlKitResults.size(); i++) {
                            if (mlKitResults.get(i).getFilename().equals(filename)) {
                                mlKitResults.remove(i);
                                break;
                            }
                        }
                    }
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {}

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        };
        databaseRef.addChildEventListener(childEventListener);

        // 4. Set list item click listener
        listView.setOnItemClickListener((parent, view, position, id) -> {
            MLKitResult selected = mlKitResults.get(position);
            Intent intent = new Intent(this, Activity7.class);
            intent.putExtra("FIREBASE_KEY", selected.getFilename());
            intent.putExtra("READER_LABEL", selected.getReader());
            intent.putExtra("ML_RESULTS", selected.getText());
            intent.putExtra("IMAGE_FILENAME", selected.getFilename());
            startActivity(intent);
        });

        // 5. Set btnAdd click listener
        btnAdd.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity1.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        mlKitResults.clear();
        adapter.notifyDataSetChanged();
        // addChildEventListener re-fires onChildAdded for existing items automatically
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (databaseRef != null && childEventListener != null) {
            databaseRef.removeEventListener(childEventListener);
        }
    }
}
