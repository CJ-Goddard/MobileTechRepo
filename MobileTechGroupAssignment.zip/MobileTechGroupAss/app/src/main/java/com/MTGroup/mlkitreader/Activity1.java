package com.MTGroup.mlkitreader;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Activity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);

        ImageView imageBarcode = findViewById(R.id.imageBarcode);
        ImageView imageContent = findViewById(R.id.imageContent);
        ImageView imageText = findViewById(R.id.imageText);
        Button btnListImages = findViewById(R.id.btnListImages);

        imageBarcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityWithExtra("barcode");
            }
        });

        imageContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityWithExtra("content");
            }
        });

        imageText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityWithExtra("text");
            }
        });

        btnListImages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity1.this, Activity6.class);
                startActivity(intent);
            }
        });
    }

    private void startActivityWithExtra(String readerType) {
        Intent intent = new Intent(Activity1.this, Activity2.class);
        intent.putExtra("READER_TYPE", readerType);
        startActivity(intent);
    }
}
